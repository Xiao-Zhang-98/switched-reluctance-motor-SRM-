#! Flux2D 20.0
loadProject('C:/Users/Xiao/Desktop/SRM_overlay/SRM_Motor.FLU')

lastInstance = VariationParameterFormula(name='VariationParameter_3',
                          formula='COIL_PHA1')

Scenario['SCENARIO_1'].solve(projectName='C:/Users/Xiao/Desktop/SRM_overlay/SRM_Motor.FLU')

DeleteAllResults(deletePostprocessingResults='yes')

VariationParameterFormula['VARIATIONPARAMETER_1','VARIATIONPARAMETER_3','VARIATIONPARAMETER_2'].deleteForce()
Scenario['SCENARIO_1'].solve(projectName='C:/Users/Xiao/Desktop/SRM_overlay/SRM_Motor.FLU')

saveProject()

closeProject()

exit()
