#! Flux2D 20.0
#! Thu Aug 20 11:19:29 EDT 2020 loadProject('C:/Users/Xiao/Desktop/SRM_overlay/SRM_Motor.FLU')

lastInstance = VariationParameterFormula(name='VariationParameter_1',
                          formula='V(EQUIPOTENTIAL_1)-V(EQUIPOTENTIAL_3)')

lastInstance = VariationParameterFormula(name='VARIATIONPARAMETER_2',
                          formula='V(EQUIPOTENTIAL_1)-V(EQUIPOTENTIAL_3)')

DeleteAllResults(deletePostprocessingResults='yes')

saveProject()

exit()
