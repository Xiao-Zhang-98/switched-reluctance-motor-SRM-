#! Flux2D 20.0
#! Thu Aug 20 11:19:29 EDT 2020 loadProject('C:/Users/Xiao/Desktop/SRM_overlay/SRM_Motor.FLU')

lastInstance = VariationParameterFormula(name='VariationParameter_1',
                          formula='V(EQUIPOTENTIAL_1)-V(EQUIPOTENTIAL_3)')

lastInstance = VariationParameterFormula(name='VARIATIONPARAMETER_2',
                          formula='V(EQUIPOTENTIAL_1)-V(EQUIPOTENTIAL_3)')

DeleteAllResults(deletePostprocessingResults='yes')

saveProject()

#! Fri Aug 21 13:38:09 EDT 2020 loadProject('C:/Users/Xiao/Desktop/SRM_overlay/SRM_Motor.FLU')

lastInstance = VariationParameterFormula(name='VariationParameter_3',
                          formula='COIL_PHA1')

Scenario['SCENARIO_1'].solve(projectName='C:/Users/Xiao/Desktop/SRM_overlay/SRM_Motor.FLU')

DeleteAllResults(deletePostprocessingResults='yes')

VariationParameterFormula['VARIATIONPARAMETER_1','VARIATIONPARAMETER_3','VARIATIONPARAMETER_2'].deleteForce()
Scenario['SCENARIO_1'].solve(projectName='C:/Users/Xiao/Desktop/SRM_overlay/SRM_Motor.FLU')

saveProject()

#! Fri Aug 21 19:16:59 EDT 2020 loadProject('C:/Users/Xiao/Desktop/SRM_overlay/SRM_Motor.FLU')

DeleteAllResults(deletePostprocessingResults='yes')

saveProject()

