#! Flux2D 20.0
newProject()

SketcherOption[1].magnetizationGrid=MagnetizationGrid(gridActivation='OUI',lengthGridCell=10.0,cellSubdivision=10,subdivisionPoint=10)

openSketcher2dContext()

closeSketcher2dContext()

buildFaces()

loadOverlay(name='Switched_Reluctance_Motors.PFO')

lastInstance = MotorSR(name='MotorSR_1',
        lengthUnit='Millimeter',
        meshFactor=0.5,
        GAP=0.3,
        excentricity=ExcentricityNo(periodicity='No',
                                    bdr='2_layers_airgap'),
        rotor=RotorNoStep(R1=41.5,
                          R0=30.5,
                          Rsh=12.5,
                          Nr=8,
                          BetaR=15.0,
                          tpr_R=3.0,
                          fil_R=0.5,
                          rotorAng=0.0),
        stator=StatorTaperedPole(R2=56.7,
                                 R3=68.0,
                                 Ns=12,
                                 BetaS=15.0,
                                 lamShape=LamShapeCircle(),
                                 tpr_S=4.0,
                                 fil_S=0.5,
                                 D1s=0.2,
                                 tpr_T=1.0,
                                 bottomShape=StatorTaperedSlotShapeWithDeepening(tab=1.0)),
        infiniteBox=InfiniteDisc(rInt=110.0,
                                 rExt=140.0),
        winding=Winding(nPhases=3,
                        polarisations='NSN'))

leaveOverlay()
saveProjectAs('SRM_Motor.FLU')

lastInstance = ApplicationMagneticTransient2D(domain2D=Domain2DPlane(lengthUnit=LengthUnit['MILLIMETER'],
                                                      depth='70'),
                               coilCoefficient=CoilCoefficientAutomatic(),
                               transientInitialization=TransientInitializationZeroInitialSolution())

MeshPoint['AIRGAP'].value='((DMINSTATOR-DMAXROTOR)/NB_REGION_IN_AIRGAP)*10**3*LENGTH_UNIT*2'


meshFaces()

Material(name='ChinaSteel_35CS300_AC_60Hz', propertyBH=PropertyBhNonlinearSpline(splinePoints=[BHPoint(h=0.0, b=0.0), BHPoint(h=19.56848067417651, b=0.5336012643765669), BHPoint(h=37.30241628514897, b=0.7778407309955043), BHPoint(h=74.60483257029794, b=1.0409966490482738), BHPoint(h=112.82452138704895, b=1.176168594273206), BHPoint(h=160.5991324079877, b=1.272580026423332), BHPoint(h=220.3173961841611, b=1.3436805620423056), BHPoint(h=294.9652259043779, b=1.3975845588927043), BHPoint(h=388.2750130546489, b=1.439507644403735), BHPoint(h=504.91224699248767, b=1.4729864963341877), BHPoint(h=650.7087894147861, b=1.5005392508147157), BHPoint(h=832.9544674426592, b=1.524047803709834), BHPoint(h=1060.7615649775005, b=1.544993250429875), BHPoint(h=1345.5204368960522, b=1.5646102790900098), BHPoint(h=1701.4690267942417, b=1.5839956826906585), BHPoint(h=2146.4047641669786, b=1.6041909612857002), BHPoint(h=2702.5744358828997, b=1.626251126352815), BHPoint(h=3397.786525527801, b=1.6513376347664974), BHPoint(h=4266.801637583928, b=1.6804082468695678), BHPoint(h=5353.070527654087, b=1.713625768754521), BHPoint(h=6710.906640241785, b=1.7508588706517976), BHPoint(h=8408.201780976407, b=1.7916493556656776), BHPoint(h=10529.820706894685, b=1.8351367310202273), BHPoint(h=13181.844364292532, b=1.8800081934738635), BHPoint(h=16496.87393603984, b=1.9244884732668914), BHPoint(h=20640.660900723975, b=1.966375977023312), BHPoint(h=25820.394606579146, b=2.0031183481151866), BHPoint(h=32295.061738898108, b=2.0319061310479727), BHPoint(h=40388.395654296815, b=2.0497535548311268), BHPoint(h=44427.2352197265, b=2.0548289103142396)], equivalentHarmonicCurve=EquivalentBhUnmodified()))

Material['CHINASTEEL_35CS300_AC_60HZ'].delete()
Material(name='ChinaSteel_35CS300_DC', propertyBH=PropertyBhNonlinearSpline(splinePoints=[BHPoint(h=0.0, b=0.0), BHPoint(h=20.353802691689854, b=0.5448000112427636), BHPoint(h=38.799436381033786, b=0.7889585421663896), BHPoint(h=77.59887276206757, b=1.0485292558647907), BHPoint(h=117.35239364427431, b=1.1805308336442613), BHPoint(h=167.04429474703275, b=1.2741989810429877), BHPoint(h=229.15917112548078, b=1.343087597348991), BHPoint(h=306.8027665985408, b=1.3952843313978818), BHPoint(h=403.8572609398659, b=1.4359483993383941), BHPoint(h=525.1753788665222, b=1.468562710114311), BHPoint(h=676.8230262748426, b=1.495604302564239), BHPoint(h=866.3825855352432, b=1.5189293038205944), BHPoint(h=1103.332034610744, b=1.5400088106980714), BHPoint(h=1399.5188459551198, b=1.5600833804296683), BHPoint(h=1769.7523601355895, b=1.5802720072785184), BHPoint(h=2232.5442528611766, b=1.6016558531596319), BHPoint(h=2811.0341187681606, b=1.6253490064472254), BHPoint(h=3534.1464511518907, b=1.6525643533701784), BHPoint(h=4438.0368666315535, b=1.6846804741941166), BHPoint(h=5567.899885981132, b=1.7217874207444244), BHPoint(h=6980.228660168104, b=1.7622386827334395), BHPoint(h=8745.639627901819, b=1.805223838095746), BHPoint(h=10952.403337568963, b=1.8495947773908805), BHPoint(h=13710.857974652894, b=1.893892377877072), BHPoint(h=17158.926271007807, b=1.9364186310168086), BHPoint(h=21469.01164145145, b=1.975334148776777), BHPoint(h=26856.618354506, b=2.0087573120861113), BHPoint(h=33591.12674582419, b=2.034838750346135), BHPoint(h=42009.26223497193, b=2.0517903958480463), BHPoint(h=46210.18845846913, b=2.0570694354328505)], equivalentHarmonicCurve=EquivalentBhUnmodified()))

Material(name='FLU_COPPER', propertyBH=PropertyBhLinear(mur='1.0'), thermalConductivity=KtIsotropic(k='394.0'), specificHeat=RhoCpConstant(rhoCp='3518000.0'), propertyJE=PropertyJeTLinearFunction(slope='0.00427', rhoConstant='1.564E-8', referenceTemperature=Temperature(temperature='0.0'), temperature=Temperature(temperature='20.0')))

lastInstance = MechanicalSetRotation1Axis(name='Rotor',
                           kinematics=RotatingImposedSpeed(velocity='1000',
                                                           initialPosition='0'),
                           rotationAxis=RotationZAxis(coordSys=CoordSys['XY1'],
                                                      pivot=['0',
                                                             '0']))

lastInstance = MechanicalSetFixed(name='Stator')

exportCircuit(filename='SRM_Motor_log1.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='SRM_Motor_log1.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

startMacroTransaction()
RegionFace['INFINITE'].magneticTransient2D=MagneticTransient2DFaceVacuum()

RegionFace['INFINITE'].mechanicalSet=MechanicalSet['STATOR']

endMacroTransaction()

startMacroTransaction()
RegionFace['ROTATING_AIRGAP'].magneticTransient2D=MagneticTransient2DFaceVacuum()

RegionFace['ROTATING_AIRGAP'].mechanicalSet=MechanicalSet['STATOR']

endMacroTransaction()

startMacroTransaction()
RegionFace['ROTOR'].magneticTransient2D=MagneticTransient2DFaceMagnetic(material=Material['CHINASTEEL_35CS300_DC'])

RegionFace['ROTOR'].mechanicalSet=MechanicalSet['ROTOR']

endMacroTransaction()

startMacroTransaction()
RegionFace['ROTOR_AIR'].magneticTransient2D=MagneticTransient2DFaceVacuum()

RegionFace['ROTOR_AIR'].mechanicalSet=MechanicalSet['ROTOR']

endMacroTransaction()

startMacroTransaction()
RegionFace['SHAFT'].magneticTransient2D=MagneticTransient2DFaceVacuum()

RegionFace['SHAFT'].mechanicalSet=MechanicalSet['ROTOR']

endMacroTransaction()

startMacroTransaction()
RegionFace['STATOR'].magneticTransient2D=MagneticTransient2DFaceMagnetic(material=Material['CHINASTEEL_35CS300_DC'])

RegionFace['STATOR'].mechanicalSet=MechanicalSet['STATOR']

endMacroTransaction()

startMacroTransaction()
RegionFace['STATOR_AIR'].magneticTransient2D=MagneticTransient2DFaceVacuum()

RegionFace['STATOR_AIR'].mechanicalSet=MechanicalSet['STATOR']

endMacroTransaction()

startMacroTransaction()
RegionFace['PHASE_NEG_1','PHASE_NEG_2','PHASE_NEG_3','PHASE_POS_1','PHASE_POS_2','PHASE_POS_3'].mechanicalSet=MechanicalSet['STATOR']

RegionFace['PHASE_NEG_1'].magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DNegative(turnNumber='112',
                                                                                                                         seriesParallel=AllInSeries(),
                                                                                                                         electricComponent=CoilConductor['A1']),
                                                                                   material=Material['FLU_COPPER'])

RegionFace['PHASE_NEG_2'].magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DNegative(turnNumber='112',
                                                                                                                         seriesParallel=AllInSeries(),
                                                                                                                         electricComponent=CoilConductor['B1']),
                                                                                   material=Material['FLU_COPPER'])

RegionFace['PHASE_NEG_3'].magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DNegative(turnNumber='112',
                                                                                                                         seriesParallel=AllInSeries(),
                                                                                                                         electricComponent=CoilConductor['C1']),
                                                                                   material=Material['FLU_COPPER'])

RegionFace['PHASE_POS_1'].magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DPositive(turnNumber='112',
                                                                                                                         seriesParallel=AllInSeries(),
                                                                                                                         electricComponent=CoilConductor['A2']),
                                                                                   material=Material['FLU_COPPER'])

RegionFace['PHASE_POS_2'].magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DPositive(turnNumber='112',
                                                                                                                         seriesParallel=AllInSeries(),
                                                                                                                         electricComponent=CoilConductor['B2']),
                                                                                   material=Material['FLU_COPPER'])

RegionFace['PHASE_POS_3'].magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DPositive(turnNumber='112',
                                                                                                                         seriesParallel=AllInSeries(),
                                                                                                                         electricComponent=CoilConductor['C2']),
                                                                                   material=Material['FLU_COPPER'])

endMacroTransaction()

result = checkPhysic()

exportCircuit(filename='SRM_Motor_log2.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='SRM_Motor_log2.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

lastInstance = VariationParameterFormula(name='Voltage1',
                          formula='V(EQUIPOTENTIAL_1)-V(EQUIPOTENTIAL_3)')

VariationParameterFormula['VOLTAGE1'].delete()
exportCircuit(filename='SRM_Motor_log3.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='SRM_Motor_log3.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

lastInstance = VariationParameterFormula(name='Voltage1',
                          formula='V(EQUIPOTENTIAL_1)-V(EQUIPOTENTIAL_3)')

lastInstance = SensorPredefinedMagneticFlux(name='Coil_PHA1',
                             support=ComputationSupportFacesMagneticFlux(faces=[Face[56],
                                                                                Face[150]]))

Scenario(name='Scenario_1')

startMacroTransaction()

Scenario['Scenario_1'].addPilot(pilot=MultiValues(parameter=VariationParameter['TIME'],
                                                  intervals=[IntervalStepValue(minValue=0.0,
                                                                               maxValue=0.015,
                                                                               stepValue=6.25E-5)]))

endMacroTransaction()

Scenario['SCENARIO_1'].solve(projectName='SRM_Motor.FLU')

EvolutiveCurve2D(name='Torque',
                 evolutivePath=EvolutivePath(parameterSet=[SetParameterXVariable(paramEvol=VariationParameter['TIME'],
                                                                                 limitMin=0.0,
                                                                                 limitMax=0.015)]),
                 formula=['TorqueElecMag(ROTOR)'])

EvolutiveCurve2D(name='Coil_PHA1',
                 evolutivePath=EvolutivePath(parameterSet=[SetParameterXVariable(paramEvol=VariationParameter['TIME'],
                                                                                 limitMin=0.0,
                                                                                 limitMax=0.015)]),
                 formula=['COIL_PHA1'])

EvolutiveCurve2D(name='VP1',
                 evolutivePath=EvolutivePath(parameterSet=[SetParameterXVariable(paramEvol=VariationParameter['TIME'],
                                                                                 limitMin=0.0,
                                                                                 limitMax=0.015)]),
                 formula=['VOLTAGE1'])

displayIsolines()

displayIsolines()

displayIsovalues()

selectCurrentStep(activeScenario=Scenario['SCENARIO_1'],
                  parameterValue=['TIME=0.0046875'])

displayIsovalues()

displayIsolines()

saveProject()

