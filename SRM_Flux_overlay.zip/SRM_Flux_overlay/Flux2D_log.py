#! Flux2D 20.0
loadProject('C:/Users/Xiao/Desktop/SRM_overlay/SRM_Motor.FLU')

DeleteAllResults(deletePostprocessingResults='yes')

saveProject()

closeProject()

exit()
