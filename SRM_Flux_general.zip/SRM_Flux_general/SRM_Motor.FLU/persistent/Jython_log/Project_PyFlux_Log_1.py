saveProjectAs('SRM_Motor.FLU')

#! Wed Aug 12 21:18:41 EDT 2020 loadProject('C:/Users/Xiao/Desktop/SRM_general/SRM_Motor.FLU')

openSketcher2dContext()

closeSketcher2dContext()

buildFaces()

lastInstance = ApplicationMagneticTransient2D(domain2D=Domain2DPlane(lengthUnit=LengthUnit['MILLIMETER'],
                                                      depth='70'),
                               coilCoefficient=CoilCoefficientAutomatic(),
                               transientInitialization=TransientInitializationZeroInitialSolution())

saveProject()

lastInstance = InfiniteBoxDisc(DISCOID=['110',
                         '140'])

lastInstance = MeshLineGeometricLength(name='rotor_teeth',
                        color=Color['White'],
                        lengthUnit=LengthUnit['MILLIMETER'],
                        minimalDistance='0.21729',
                        concentrationFactor='1')

LineArcPivotRadiusAnglePoint[5,42,40,38,36,6,14,46,44,33].assignMeshLine(meshLine=MeshLine['ROTOR_TEETH'])

lastInstance = MeshLineGeometricLength(name='stator_teeth',
                        color=Color['White'],
                        lengthUnit=LengthUnit['MILLIMETER'],
                        minimalDistance='0.21886',
                        concentrationFactor='1')

LineArcPivotRadiusAnglePoint[137,15,135,133,131,129,110,34,64,147,145,143,141,139].assignMeshLine(meshLine=MeshLine['STATOR_TEETH'])

lastInstance = MeshLineGeometricLength(name='coils',
                        color=Color['White'],
                        lengthUnit=LengthUnit['MILLIMETER'],
                        minimalDistance='1.9793',
                        concentrationFactor='1')

LineArcPivotRadiusAnglePoint[119,157,117,155,115,153,113,151,109,149,61,66,71,167,127,165,125,163,123,161,121,159,105,106].assignMeshLine(meshLine=MeshLine['COILS'])

FaceAutomatic[2,1,4,13,12,11,3,10,9,6,20,21,40,18,16,14,17,49,38,39,48,19,36,37,47,34,35,46,32,33,45,30,31,8,28,29,44,26,27,43,24,25,42,22,23,41,15].assignMeshGenerator(meshGenerator=MeshGenerator['AUTOMATIC'])

AidedMesh[1].synchronize()

meshFaces()

lastInstance = RegionFace(name='RegionFace_1',
           magneticTransient2D=MagneticTransient2DFaceVacuum(),
           color=Color['Turquoise'],
           visibility=Visibility['VISIBLE'])

Face[2].region=RegionFace['REGIONFACE_1']


AidedMesh[1].aidedMeshState=AidedMeshActivated(meshPoint=MeshPointAssigned(type=MeshPointDynamic()),
                                               meshDeviation=MeshDeviationAssignedIncludeIB(type=MeshDeviationIncludeIBRelative(value=0.5)),
                                               meshRelaxation=MeshRelaxation(lineMeshRelaxation=LineMeshRelaxationAssigned(type=LineMeshRelaxationMedium()),
                                                                             faceMeshRelaxation=FaceMeshRelaxationAssigned(type=FaceMeshRelaxationMedium())))


meshFaces()

saveProject()

#! Wed Aug 12 21:45:01 EDT 2020 loadProject('C:/Users/Xiao/Desktop/SRM_general/SRM_Motor.FLU')

meshFaces()

deleteMesh()

openSketcher2dContext()

closeSketcher2dContext()

buildFaces()

InfiniteBoxDisc['InfiniteBoxDisc'].delete()
MeshLineGeometricLength['STATOR_TEETH','ROTOR_TEETH','COILS'].deleteForce()
RegionFace['REGIONFACE_1'].deleteForce()
lastInstance = InfiniteBoxDisc(DISCOID=['110',
                         '140'])

InfiniteBoxDisc['InfiniteBoxDisc'].complete2D(buildingOption='Faces',
           coordSys=CoordSys['XY1'],
           linkMesh='LinkMesh')

AidedMesh[1].aidedMeshState=AidedMeshActivated(meshPoint=MeshPointAssigned(type=MeshPointDynamic()),
                                               meshDeviation=MeshDeviationAssignedExcludeIB(type=MeshDeviationExcludeIBRelative(value=0.5)),
                                               meshRelaxation=MeshRelaxation(lineMeshRelaxation=LineMeshRelaxationAssigned(type=LineMeshRelaxationMedium()),
                                                                             faceMeshRelaxation=FaceMeshRelaxationAssigned(type=FaceMeshRelaxationMedium())))


lastInstance = MeshLineGeometricLength(name='rotor_teeth',
                        color=Color['White'],
                        lengthUnit=LengthUnit['MILLIMETER'],
                        minimalDistance='0.21729',
                        concentrationFactor='1')

LineArcPivotRadiusAnglePoint[42,5,40,38,36,14,6,46,44,33].assignMeshLine(meshLine=MeshLine['ROTOR_TEETH'])

lastInstance = MeshLineGeometricLength(name='stator_teeth',
                        color=Color['White'],
                        lengthUnit=LengthUnit['MILLIMETER'],
                        minimalDistance='0.21886',
                        concentrationFactor='1')

LineArcPivotRadiusAnglePoint[15,137,135,133,131,129,110,64,34,147,145,143,141,139].assignMeshLine(meshLine=MeshLine['STATOR_TEETH'])

lastInstance = MeshLineGeometricLength(name='coils',
                        color=Color['White'],
                        lengthUnit=LengthUnit['MILLIMETER'],
                        minimalDistance='1.9793',
                        concentrationFactor='1')

LineArcPivotRadiusAnglePoint[119,157,117,155,115,153,113,151,109,149,61,66,71,167,127,165,163,125,161,123,159,121,106,105].assignMeshLine(meshLine=MeshLine['COILS'])

FaceAutomatic[2,1,4,6,9,10,3,11,12,13,38,49,19,17,14,18,16,40,21,20,41,23,42,22,24,43,25,27,26,44,29,28,8,31,30,45,33,32,46,35,34,47,37,36,48,39,15].assignMeshGenerator(meshGenerator=MeshGenerator['AUTOMATIC'])

AidedMesh[1].synchronize()

meshFaces()

meshFaces()

Material(name='ChinaSteel_35CS300_DC', propertyBH=PropertyBhNonlinearSpline(splinePoints=[BHPoint(h=0.0, b=0.0), BHPoint(h=20.353802691689854, b=0.5448000112427636), BHPoint(h=38.799436381033786, b=0.7889585421663896), BHPoint(h=77.59887276206757, b=1.0485292558647907), BHPoint(h=117.35239364427431, b=1.1805308336442613), BHPoint(h=167.04429474703275, b=1.2741989810429877), BHPoint(h=229.15917112548078, b=1.343087597348991), BHPoint(h=306.8027665985408, b=1.3952843313978818), BHPoint(h=403.8572609398659, b=1.4359483993383941), BHPoint(h=525.1753788665222, b=1.468562710114311), BHPoint(h=676.8230262748426, b=1.495604302564239), BHPoint(h=866.3825855352432, b=1.5189293038205944), BHPoint(h=1103.332034610744, b=1.5400088106980714), BHPoint(h=1399.5188459551198, b=1.5600833804296683), BHPoint(h=1769.7523601355895, b=1.5802720072785184), BHPoint(h=2232.5442528611766, b=1.6016558531596319), BHPoint(h=2811.0341187681606, b=1.6253490064472254), BHPoint(h=3534.1464511518907, b=1.6525643533701784), BHPoint(h=4438.0368666315535, b=1.6846804741941166), BHPoint(h=5567.899885981132, b=1.7217874207444244), BHPoint(h=6980.228660168104, b=1.7622386827334395), BHPoint(h=8745.639627901819, b=1.805223838095746), BHPoint(h=10952.403337568963, b=1.8495947773908805), BHPoint(h=13710.857974652894, b=1.893892377877072), BHPoint(h=17158.926271007807, b=1.9364186310168086), BHPoint(h=21469.01164145145, b=1.975334148776777), BHPoint(h=26856.618354506, b=2.0087573120861113), BHPoint(h=33591.12674582419, b=2.034838750346135), BHPoint(h=42009.26223497193, b=2.0517903958480463), BHPoint(h=46210.18845846913, b=2.0570694354328505)], equivalentHarmonicCurve=EquivalentBhUnmodified()))

Material(name='FLU_COPPER', propertyBH=PropertyBhLinear(mur='1.0'), thermalConductivity=KtIsotropic(k='394.0'), specificHeat=RhoCpConstant(rhoCp='3518000.0'), propertyJE=PropertyJeTLinearFunction(slope='0.00427', rhoConstant='1.564E-8', referenceTemperature=Temperature(temperature='0.0'), temperature=Temperature(temperature='20.0')))

lastInstance = MechanicalSetRotation1Axis(name='rotor',
                           kinematics=RotatingImposedSpeed(velocity='1000',
                                                           initialPosition='0'),
                           rotationAxis=RotationZAxis(coordSys=CoordSys['XY1'],
                                                      pivot=['0',
                                                             '0']))

lastInstance = MechanicalSetFixed(name='stator')

exportCircuit(filename='SRM_Motor_log1.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='SRM_Motor_log1.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

MechanicalSet[ALL].deleteForce()
Material[ALL].deleteForce()
Material(name='ChinaSteel_35CS300_DC', propertyBH=PropertyBhNonlinearSpline(splinePoints=[BHPoint(h=0.0, b=0.0), BHPoint(h=20.353802691689854, b=0.5448000112427636), BHPoint(h=38.799436381033786, b=0.7889585421663896), BHPoint(h=77.59887276206757, b=1.0485292558647907), BHPoint(h=117.35239364427431, b=1.1805308336442613), BHPoint(h=167.04429474703275, b=1.2741989810429877), BHPoint(h=229.15917112548078, b=1.343087597348991), BHPoint(h=306.8027665985408, b=1.3952843313978818), BHPoint(h=403.8572609398659, b=1.4359483993383941), BHPoint(h=525.1753788665222, b=1.468562710114311), BHPoint(h=676.8230262748426, b=1.495604302564239), BHPoint(h=866.3825855352432, b=1.5189293038205944), BHPoint(h=1103.332034610744, b=1.5400088106980714), BHPoint(h=1399.5188459551198, b=1.5600833804296683), BHPoint(h=1769.7523601355895, b=1.5802720072785184), BHPoint(h=2232.5442528611766, b=1.6016558531596319), BHPoint(h=2811.0341187681606, b=1.6253490064472254), BHPoint(h=3534.1464511518907, b=1.6525643533701784), BHPoint(h=4438.0368666315535, b=1.6846804741941166), BHPoint(h=5567.899885981132, b=1.7217874207444244), BHPoint(h=6980.228660168104, b=1.7622386827334395), BHPoint(h=8745.639627901819, b=1.805223838095746), BHPoint(h=10952.403337568963, b=1.8495947773908805), BHPoint(h=13710.857974652894, b=1.893892377877072), BHPoint(h=17158.926271007807, b=1.9364186310168086), BHPoint(h=21469.01164145145, b=1.975334148776777), BHPoint(h=26856.618354506, b=2.0087573120861113), BHPoint(h=33591.12674582419, b=2.034838750346135), BHPoint(h=42009.26223497193, b=2.0517903958480463), BHPoint(h=46210.18845846913, b=2.0570694354328505)], equivalentHarmonicCurve=EquivalentBhUnmodified()))

Material(name='FLU_COPPER', propertyBH=PropertyBhLinear(mur='1.0'), thermalConductivity=KtIsotropic(k='394.0'), specificHeat=RhoCpConstant(rhoCp='3518000.0'), propertyJE=PropertyJeTLinearFunction(slope='0.00427', rhoConstant='1.564E-8', referenceTemperature=Temperature(temperature='0.0'), temperature=Temperature(temperature='20.0')))

lastInstance = MechanicalSetRotation1Axis(name='rotor',
                           kinematics=RotatingImposedSpeed(velocity='1000',
                                                           initialPosition='0'),
                           rotationAxis=RotationZAxis(coordSys=CoordSys['XY1'],
                                                      pivot=['0',
                                                             '0']))

lastInstance = MechanicalSetFixed(name='stator')

exportCircuit(filename='SRM_Motor_log2.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='SRM_Motor_log2.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

saveProject()

