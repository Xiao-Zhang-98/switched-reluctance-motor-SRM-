#! Flux2D 20.0


# Your project log file has become too 
# large and it is unsafe to open in Flux.
# It has been archived as C:\Users\Xiao\Desktop\SRM_general\SRM_Motor.FLU\persistent\Jython_log\Project_PyFlux_Log_2.py.
# If needed, consider opening it in a high 
# performance dedicated editor.

#! Thu Aug 20 15:49:25 EDT 2020 loadProject('C:/Users/Xiao/Desktop/SRM_general/SRM_Motor.FLU')

displayIsolines()

displayIsovalues()

lastInstance = VariationParameterFormula(name='VariationParameter_1',
                          formula='VOLTAGE1')

lastInstance = VariationParameterFormula(name='VARIATIONPARAMETER_2',
                          formula='1')

lastInstance = VariationParameterFormula(name='VARIATIONPARAMETER_3',
                          formula='VOLTAGE1')

EvolutiveCurve2D(name='PHA1_1',
                 evolutivePath=EvolutivePath(parameterSet=[SetParameterXVariable(paramEvol=VariationParameter['TIME'],
                                                                                 limitMin=0.0,
                                                                                 limitMax=0.015)]),
                 formula=['PHA1'])

Curve2d['PHA1_1'].visible=0

VariationParameterFormula['VOLTAGE1'].exportTXT(txtFile='../New folder',
          mode='add')

VariationParameterFormula['VOLTAGE1'].exportExcel(xlsFile='../New folder',
            mode='add')

VariationParameterFormula['VARIATIONPARAMETER_1','VARIATIONPARAMETER_2','VARIATIONPARAMETER_3'].deleteForce()
VariationParameterFormula['VOLTAGE1'].exportTXT(txtFile='../New folder',
          mode='add')

lastInstance = VariationParameterFormula(name='VariationParameter_1',
                          formula='TIME')

predefine['PHA1'].editDynamicInstance()

result = Sensor['PHA1'].type()
predefine['PHA1'].exportClipboard()
predefine['PHA1'].exportXML(xmlFile='../New folder',
          mode='replace')

predefine['PHA1'].exportExcel(xlsFile='../New folder.bak',
            mode='replace')

saveProject()

#! Fri Aug 21 13:50:26 EDT 2020 loadProject('C:/Users/Xiao/Desktop/SRM_general/SRM_Motor.FLU')

predefine['PHA1'].exportExcel(xlsFile='../Test',
            mode='add')

saveProject()

#! Fri Aug 21 19:16:17 EDT 2020 loadProject('C:/Users/Xiao/Desktop/SRM_general/SRM_Motor.FLU')

DeleteAllResults(deletePostprocessingResults='yes')

saveProject()

