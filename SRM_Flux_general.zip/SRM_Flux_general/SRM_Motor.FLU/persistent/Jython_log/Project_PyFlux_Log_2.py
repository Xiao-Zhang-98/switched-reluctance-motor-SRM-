#! Flux2D 20.0
#! Thu Aug 13 14:36:53 EDT 2020 loadProject('C:/Users/Xiao/Desktop/SRM_general/SRM_Motor.FLU')

Material[ALL].deleteForce()
MechanicalSet[ALL].deleteForce()
exportCircuit(filename='SRM_Motor_log1.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='SRM_Motor_log1.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

Material(name='ChinaSteel_35CS300_DC', propertyBH=PropertyBhNonlinearSpline(splinePoints=[BHPoint(h=0.0, b=0.0), BHPoint(h=20.353802691689854, b=0.5448000112427636), BHPoint(h=38.799436381033786, b=0.7889585421663896), BHPoint(h=77.59887276206757, b=1.0485292558647907), BHPoint(h=117.35239364427431, b=1.1805308336442613), BHPoint(h=167.04429474703275, b=1.2741989810429877), BHPoint(h=229.15917112548078, b=1.343087597348991), BHPoint(h=306.8027665985408, b=1.3952843313978818), BHPoint(h=403.8572609398659, b=1.4359483993383941), BHPoint(h=525.1753788665222, b=1.468562710114311), BHPoint(h=676.8230262748426, b=1.495604302564239), BHPoint(h=866.3825855352432, b=1.5189293038205944), BHPoint(h=1103.332034610744, b=1.5400088106980714), BHPoint(h=1399.5188459551198, b=1.5600833804296683), BHPoint(h=1769.7523601355895, b=1.5802720072785184), BHPoint(h=2232.5442528611766, b=1.6016558531596319), BHPoint(h=2811.0341187681606, b=1.6253490064472254), BHPoint(h=3534.1464511518907, b=1.6525643533701784), BHPoint(h=4438.0368666315535, b=1.6846804741941166), BHPoint(h=5567.899885981132, b=1.7217874207444244), BHPoint(h=6980.228660168104, b=1.7622386827334395), BHPoint(h=8745.639627901819, b=1.805223838095746), BHPoint(h=10952.403337568963, b=1.8495947773908805), BHPoint(h=13710.857974652894, b=1.893892377877072), BHPoint(h=17158.926271007807, b=1.9364186310168086), BHPoint(h=21469.01164145145, b=1.975334148776777), BHPoint(h=26856.618354506, b=2.0087573120861113), BHPoint(h=33591.12674582419, b=2.034838750346135), BHPoint(h=42009.26223497193, b=2.0517903958480463), BHPoint(h=46210.18845846913, b=2.0570694354328505)], equivalentHarmonicCurve=EquivalentBhUnmodified()))

Material(name='FLU_COPPER', propertyBH=PropertyBhLinear(mur='1.0'), thermalConductivity=KtIsotropic(k='394.0'), specificHeat=RhoCpConstant(rhoCp='3518000.0'), propertyJE=PropertyJeTLinearFunction(slope='0.00427', rhoConstant='1.564E-8', referenceTemperature=Temperature(temperature='0.0'), temperature=Temperature(temperature='20.0')))

lastInstance = MechanicalSetRotation1Axis(name='rotor',
                           kinematics=RotatingImposedSpeed(velocity='1000',
                                                           initialPosition='-22.5'),
                           rotationAxis=RotationZAxis(coordSys=CoordSys['XY1'],
                                                      pivot=['0',
                                                             '0']))

lastInstance = MechanicalSetFixed(name='stator')

exportCircuit(filename='SRM_Motor_log2.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='SRM_Motor_log2.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

RegionFace['INFINITE'].mechanicalSet=MechanicalSet['STATOR']


lastInstance = RegionFace(name='shaft',
           magneticTransient2D=MagneticTransient2DFaceVacuum(),
           color=Color['Black'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['ROTOR'])

FaceAutomatic[2].assignRegion(region=RegionFace['SHAFT'])

lastInstance = RegionFace(name='rotor_back_iron',
           magneticTransient2D=MagneticTransient2DFaceMagnetic(material=Material['CHINASTEEL_35CS300_DC']),
           color=Color['Red'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['ROTOR'])

FaceAutomatic[1].assignRegion(region=RegionFace['ROTOR_BACK_IRON'])

lastInstance = RegionFace(name='rotor_poles',
           magneticTransient2D=MagneticTransient2DFaceMagnetic(material=Material['CHINASTEEL_35CS300_DC']),
           color=Color['Red'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['ROTOR'])

FaceAutomatic[6,4,13,12,11,3,10,9].assignRegion(region=RegionFace['ROTOR_POLES'])

lastInstance = RegionFace(name='air_rotation',
           magneticTransient2D=MagneticTransient2DFaceVacuum(),
           color=Color['Turquoise'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['ROTOR'])

FaceAutomatic[5].assignRegion(region=RegionFace['AIR_ROTATION'])

lastInstance = RegionFace(name='air_fixed',
           magneticTransient2D=MagneticTransient2DFaceVacuum(),
           color=Color['Turquoise'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[7].assignRegion(region=RegionFace['AIR_FIXED'])

lastInstance = RegionFace(name='stator_poles',
           magneticTransient2D=MagneticTransient2DFaceMagnetic(material=Material['CHINASTEEL_35CS300_DC']),
           color=Color['Cyan'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[40,14,49,48,47,46,45,8,44,43,42,41].assignRegion(region=RegionFace['STATOR_POLES'])

lastInstance = RegionFace(name='stator_back_iron',
           magneticTransient2D=MagneticTransient2DFaceMagnetic(material=Material['CHINASTEEL_35CS300_DC']),
           color=Color['Cyan'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[15].assignRegion(region=RegionFace['STATOR_BACK_IRON'])

lastInstance = RegionFace(name='air_outside',
           magneticTransient2D=MagneticTransient2DFaceVacuum(),
           color=Color['Turquoise'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[50].assignRegion(region=RegionFace['AIR_OUTSIDE'])

lastInstance = RegionFace(name='coil11',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DNegative(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['A1']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[16].assignRegion(region=RegionFace['COIL11'])

lastInstance = RegionFace(name='coil12',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DPositive(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['A2']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[17].assignRegion(region=RegionFace['COIL12'])

lastInstance = RegionFace(name='coil21',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DPositive(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['B1']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[21].assignRegion(region=RegionFace['COIL21'])

lastInstance = RegionFace(name='coil22',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DNegative(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['B2']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[18].assignRegion(region=RegionFace['COIL22'])

lastInstance = RegionFace(name='coil31',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DNegative(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['C1']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[23].assignRegion(region=RegionFace['COIL31'])

lastInstance = RegionFace(name='coil32',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DPositive(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['C2']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[20].assignRegion(region=RegionFace['COIL32'])

lastInstance = RegionFace(name='coil41',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DPositive(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['A3']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[25].assignRegion(region=RegionFace['COIL41'])

lastInstance = RegionFace(name='Coil42',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DNegative(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['A4']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[22].assignRegion(region=RegionFace['COIL42'])

lastInstance = RegionFace(name='coil51',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DNegative(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['B3']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[27].assignRegion(region=RegionFace['COIL51'])

lastInstance = RegionFace(name='coil52',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DPositive(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['B4']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[24].assignRegion(region=RegionFace['COIL52'])

lastInstance = RegionFace(name='coil61',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DPositive(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['C3']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[29].assignRegion(region=RegionFace['COIL61'])

lastInstance = RegionFace(name='coil62',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DNegative(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['C4']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[26].assignRegion(region=RegionFace['COIL62'])

lastInstance = RegionFace(name='coil71',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DNegative(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['A5']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[31].assignRegion(region=RegionFace['COIL71'])

lastInstance = RegionFace(name='coil72',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DPositive(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['A6']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[28].assignRegion(region=RegionFace['COIL72'])

lastInstance = RegionFace(name='coil81',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DPositive(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['B5']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[33].assignRegion(region=RegionFace['COIL81'])

lastInstance = RegionFace(name='coil82',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DNegative(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['B6']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[30].assignRegion(region=RegionFace['COIL82'])

lastInstance = RegionFace(name='coil91',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DNegative(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['C5']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[35].assignRegion(region=RegionFace['COIL91'])

lastInstance = RegionFace(name='COIL92',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DPositive(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['C6']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[32].assignRegion(region=RegionFace['COIL92'])

lastInstance = RegionFace(name='coil101',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DPositive(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['A7']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[37].assignRegion(region=RegionFace['COIL101'])

lastInstance = RegionFace(name='coil102',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DNegative(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['A8']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[34].assignRegion(region=RegionFace['COIL102'])

lastInstance = RegionFace(name='coil111',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DNegative(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['B7']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[39].assignRegion(region=RegionFace['COIL111'])

lastInstance = RegionFace(name='COIL112',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DPositive(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['B8']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[36].assignRegion(region=RegionFace['COIL112'])

lastInstance = RegionFace(name='coil121',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DPositive(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['C7']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[19].assignRegion(region=RegionFace['COIL121'])

lastInstance = RegionFace(name='COIL122',
           magneticTransient2D=MagneticTransient2DFaceCoilConductor(coilConductor=CoilConductor2DNegative(turnNumber='28',
                                                                                                          seriesParallel=AllInSeries(),
                                                                                                          electricComponent=CoilConductor['C8']),
                                                                    material=Material['FLU_COPPER']),
           color=Color['Yellow'],
           visibility=Visibility['VISIBLE'],
           mechanicalSet=MechanicalSet['STATOR'])

FaceAutomatic[38].assignRegion(region=RegionFace['COIL122'])

result = checkPhysic()

checkCircuit()

result = checkPhysic()

exportCircuit(filename='SRM_Motor_log3.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='SRM_Motor_log3.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

exportCircuit(filename='SRM_Motor_log4.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='SRM_Motor_log4.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

exportCircuit(filename='SRM_Motor_log5.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='SRM_Motor_log5.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

lastInstance = VariationParameterFormula(name='voltage1',
                          formula='V(EQUIPOTENTIAL_1)-V(EQUIPOTENTIAL_9)')

lastInstance = SensorPredefinedMagneticFlux(name='Sensor_1',
                             support=ComputationSupportFacesMagneticFlux(faces=[Face[16],
                                                                                Face[17]]))

Scenario(name='Scenario_1')

startMacroTransaction()

Scenario['Scenario_1'].addPilot(pilot=MultiValues(parameter=VariationParameter['TIME'],
                                                  intervals=[IntervalStepValue(minValue=0.0,
                                                                               maxValue=0.015,
                                                                               stepValue=6.25E-5)]))

endMacroTransaction()

Scenario['SCENARIO_1'].solve(projectName='C:/Users/Xiao/Desktop/SRM_general/SRM_Motor.FLU')

DeleteAllResults(deletePostprocessingResults='yes')

VariationParameterFormula['VOLTAGE1'].deleteForce()
predefine['SENSOR_1'].deleteForce()
Scenario['SCENARIO_1'].deleteForce()
exportCircuit(filename='SRM_Motor_log6.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='SRM_Motor_log6.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

exportCircuit(filename='SRM_Motor_log7.xcir')

storeCircuitLinks()

DeleteElectricCircuit(deleteStrandedConductor='YES')

importCircuit(filename='SRM_Motor_log7.xcir',
              importValue=1,
              ImportFELink=1)


restoreCircuitLinks()

lastInstance = VariationParameterFormula(name='voltage1',
                          formula='V(EQUIPOTENTIAL_1)-V(EQUIPOTENTIAL_9)')

lastInstance = SensorPredefinedMagneticFlux(name='PHA1',
                             support=ComputationSupportFacesMagneticFlux(faces=[Face[16],
                                                                                Face[17]]))

Scenario(name='Scenario_1')

startMacroTransaction()

Scenario['Scenario_1'].addPilot(pilot=MultiValues(parameter=VariationParameter['TIME'],
                                                  intervals=[IntervalStepValue(minValue=0.0,
                                                                               maxValue=0.015,
                                                                               stepValue=6.25E-5)]))

endMacroTransaction()

Scenario['SCENARIO_1'].solve(projectName='C:/Users/Xiao/Desktop/SRM_general/SRM_Motor.FLU')

EvolutiveCurve2D(name='Torque',
                 evolutivePath=EvolutivePath(parameterSet=[SetParameterXVariable(paramEvol=VariationParameter['TIME'],
                                                                                 limitMin=0.0,
                                                                                 limitMax=0.015)]),
                 formula=['TorqueElecMag(ROTOR)'])

EvolutiveCurve2D(name='PHA1',
                 evolutivePath=EvolutivePath(parameterSet=[SetParameterXVariable(paramEvol=VariationParameter['TIME'],
                                                                                 limitMin=0.0,
                                                                                 limitMax=0.015)]),
                 formula=['PHA1'])

EvolutiveCurve2D(name='voltage1',
                 evolutivePath=EvolutivePath(parameterSet=[SetParameterXVariable(paramEvol=VariationParameter['TIME'],
                                                                                 limitMin=0.0,
                                                                                 limitMax=0.015)]),
                 formula=['V(EQUIPOTENTIAL_1)-V(EQUIPOTENTIAL_9)'])

displayIsovalues()

displayIsolines()

selectCurrentStep(activeScenario=Scenario['SCENARIO_1'],
                  parameterValue=['TIME=0.0040625'])

saveProject()

