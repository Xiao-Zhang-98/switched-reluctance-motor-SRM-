#! Flux2D 20.0
newProject()

SketcherOption[1].magnetizationGrid=MagnetizationGrid(gridActivation='OUI',lengthGridCell=10.0,cellSubdivision=10,subdivisionPoint=10)

openSketcher2dContext()

createGeometry(coordSystem=CoordSys['XY1'],
               idPoints=[1,2,3],
               coordinatesPoints=['0.0','0.0','0.0','-2.920616373302047','0.0','0.0','2.920616373302047','0.0','0.0'],
               idLines=[1,2],
               typeLines=[4,4],
               pointsOfLines=[2,3,1,3,2,1],
               radius=['2.920616','2.920616'],
               angle=['180.000000','180.000000'])

Line[2].radius='12.5'


createGeometry(coordSystem=CoordSys['XY1'],
               idPoints=[4,5],
               coordinatesPoints=['-3.612478373637689','0.0','0.0','3.612478373637689','0.0','0.0'],
               idLines=[3,4],
               typeLines=[4,4],
               pointsOfLines=[4,5,1,5,4,1],
               radius=['3.612478','3.612478'],
               angle=['180.000000','180.000000'])

Line[4].radius='30.5'


createGeometry(coordSystem=CoordSys['XY1'],
               idPoints=[6,7],
               coordinatesPoints=['-40.84960220124549','0.0','0.0','40.84960220124549','0.0','0.0'],
               idLines=[5,6],
               typeLines=[4,4],
               pointsOfLines=[6,7,1,7,6,1],
               radius=['40.849602','40.849602'],
               angle=['180.000000','180.000000'])

Line[6].radius='41.5'


createGeometry(coordSystem=CoordSys['XY1'],
               idPoints=[8],
               coordinatesPoints=['49.900000000000006','9.8','0.0'],
               idLines=[7],
               typeLines=[1],
               pointsOfLines=[1,8])

createGeometry(coordSystem=CoordSys['XY1'],
               idPoints=[9],
               coordinatesPoints=['49.9','-6.7','0.0'],
               idLines=[8],
               typeLines=[1],
               pointsOfLines=[1,9])

Point[8].uvw=['49.9',
              '49.9*Tand(7.5)',
              '0']


Point[9].uvw=['49.9',
              '-49.9*Tand(7.5)',
              '0']


Line[7].adjust(coordSystem=CoordSys['XY1'],
               intersectLinesFirstPoint=[Line[2]],
               coordinatesPoints=['12.39306076717263','1.6315774027506447','0.0','30.239068271901214','3.9810488627115728','0.0'],
               intersectLinesSecondPoint=[Line[4]])

Line[7].adjust()

Line[8].adjust(coordSystem=CoordSys['XY1'],
               coordinatesPoints=['12.39306076717263','-1.6315774027506447','0.0'],
               keptPoint=Point[1],
               intersectLinesSecondPoint=[Line[1]])

Line[7].adjust(coordSystem=CoordSys['XY1'],
               coordinatesPoints=['30.239068271901214','-3.9810488627115723','0.0'],
               keptPoint=Point[12],
               intersectLinesSecondPoint=[Line[3]])

Line[9].adjust(coordSystem=CoordSys['XY1'],
               intersectLinesFirstPoint=[Line[5]],
               coordinatesPoints=['41.14496174701313','-5.41683697713214','0.0'],
               keptPoint=Point[9])

Line[11].adjust(coordSystem=CoordSys['XY1'],
               intersectLinesFirstPoint=[Line[6]],
               coordinatesPoints=['41.14496174701313','5.41683697713214','0.0'],
               keptPoint=Point[8])

healAllIntersections()

createGeometry(coordSystem=CoordSys['XY1'],
               idPoints=[8],
               coordinatesPoints=['18.699999999999996','5.41683697713214','0.0'],
               idLines=[13],
               typeLines=[1],
               pointsOfLines=[9,8])

createGeometry(coordSystem=CoordSys['XY1'],
               idPoints=[15],
               coordinatesPoints=['18.7','-5.41683697713214','0.0'],
               idLines=[16],
               typeLines=[1],
               pointsOfLines=[14,15])

Line[11].adjust()

Line[9].adjust()

Line[13].adjust(coordSystem=CoordSys['XY1'],
               intersectLinesFirstPoint=[Line[12]],
               coordinatesPoints=['30.01512747204604','5.41683697713214','0.0'],
               keptPoint=Point[8])

Line[16].adjust(coordSystem=CoordSys['XY1'],
               intersectLinesFirstPoint=[Line[3]],
               coordinatesPoints=['30.015127472046057','-5.41683697713214','0.0'],
               keptPoint=Point[15])

propagateGeometry(line=[Line[16],Line[13]],
               transformationType=3,
               transformationPoint=[Point[1]],
               coordSystem=CoordSys['XY1'],
               repetitionNumber=[8],
               repetitionValue=['45'],
               connectToOrigin=1)

Line[15].adjust()

Line[58].adjust()

Line[56].adjust()

Line[54].adjust()

Line[34].adjust()

Line[52].adjust()

Line[50].adjust()

Line[48].adjust()

createGeometry(coordSystem=CoordSys['XY1'],
               idPoints=[44,45],
               coordinatesPoints=['-52.13012156533026','0.0','0.0','52.13012156533026','0.0','0.0'],
               idLines=[15,34],
               typeLines=[4,4],
               pointsOfLines=[44,45,1,45,44,1],
               radius=['52.130122','52.130122'],
               angle=['180.000000','180.000000'])

createGeometry(coordSystem=CoordSys['XY1'],
               idPoints=[46,47],
               coordinatesPoints=['-63.114888487838016','0.0','0.0','63.114888487838016','0.0','0.0'],
               idLines=[48,50],
               typeLines=[4,4],
               pointsOfLines=[46,47,1,47,46,1],
               radius=['63.114888','63.114888'],
               angle=['180.000000','180.000000'])

Line[34].radius='41.8'


Line[50].radius='56.7'


createGeometry(coordSystem=CoordSys['XY1'],
               idPoints=[48],
               coordinatesPoints=['86.10000000000001','11.67184468713518','0.0'],
               idLines=[52],
               typeLines=[1],
               pointsOfLines=[1,48])

createGeometry(coordSystem=CoordSys['XY1'],
               idPoints=[49],
               coordinatesPoints=['86.1','-9.200000000000001','0.0'],
               idLines=[54],
               typeLines=[1],
               pointsOfLines=[1,49])

Point[48].uvw=['86.1',
               '86.1*Tand(7.5)',
               '0']


Point[49].uvw=['86.1',
               '-86.1*Tand(7.5)',
               '0']


healAllIntersections()

Line[69].adjust()

Line[67].adjust()

Line[58].adjust()

Line[52].adjust()

Line[54].adjust()

Line[56].adjust()

Line[59].adjust()

Line[60].adjust()

Line[62].adjust()

Line[61].adjust()

createGeometry(coordSystem=CoordSys['XY1'],
               idPoints=[48],
               coordinatesPoints=['57.400000000000006','5.45599483479816','0.0'],
               idLines=[52],
               typeLines=[1],
               pointsOfLines=[51,48])

createGeometry(coordSystem=CoordSys['XY1'],
               idPoints=[49],
               coordinatesPoints=['57.4','-5.45599483479816','0.0'],
               idLines=[54],
               typeLines=[1],
               pointsOfLines=[50,49])

Line[52].adjust(coordSystem=CoordSys['XY1'],
               intersectLinesFirstPoint=[Line[50]],
               coordinatesPoints=['56.43688616820259','5.45599483479816','0.0'],
               keptPoint=Point[48])

Line[54].adjust(coordSystem=CoordSys['XY1'],
               intersectLinesFirstPoint=[Line[68]],
               coordinatesPoints=['56.43688616820253','-5.45599483479816','0.0'],
               keptPoint=Point[49])

Line[63].adjust()

Line[65].adjust()

createGeometry(coordSystem=CoordSys['XY1'],
               idPoints=[49],
               coordinatesPoints=['73.3','21.328608659206015','0.0'],
               idLines=[56],
               typeLines=[1],
               pointsOfLines=[1,49])

createGeometry(coordSystem=CoordSys['XY1'],
               idPoints=[55],
               coordinatesPoints=['73.3','-21.566756826189696','0.0'],
               idLines=[60],
               typeLines=[1],
               pointsOfLines=[1,55])

Point[49].uvw=['73.3',
               '73.3*Tand(15)',
               '0']


Point[55].uvw=['73.3',
               '-73.3*Tand(15)',
               '0']


Line[56].adjust(coordSystem=CoordSys['XY1'],
               intersectLinesFirstPoint=[Line[70]],
               coordinatesPoints=['54.767994350590115','14.675039857312912','0.0'],
               keptPoint=Point[49])

Line[60].adjust(coordSystem=CoordSys['XY1'],
               intersectLinesFirstPoint=[Line[48]],
               coordinatesPoints=['54.76799435059018','-14.67503985731293','0.0'],
               keptPoint=Point[55])

Line[56].adjust(coordSystem=CoordSys['XY1'],
               intersectLinesFirstPoint=[Line[10]],
               coordinatesPoints=['12.074072828613325','3.2352380637815','0.0','29.460737701816537','7.893980875626866','0.0'],
               intersectLinesSecondPoint=[Line[11]])

Line[56].adjust()

Line[67].adjust(coordSystem=CoordSys['XY1'],
               coordinatesPoints=['40.37569953888308','10.818636085285375','0.0'],
               keptPoint=Point[57],
               intersectLinesSecondPoint=[Line[66]])

Line[60].adjust(coordSystem=CoordSys['XY1'],
               coordinatesPoints=['12.074072828613357','-3.2352380637815026','0.0'],
               keptPoint=Point[1],
               intersectLinesSecondPoint=[Line[1]])

Line[67].adjust(coordSystem=CoordSys['XY1'],
               coordinatesPoints=['29.460737701816534','-7.893980875626843','0.0'],
               keptPoint=Point[59],
               intersectLinesSecondPoint=[Line[57]])

Line[71].adjust(coordSystem=CoordSys['XY1'],
               coordinatesPoints=['40.375699538883055','-10.818636085285341','0.0'],
               keptPoint=Point[60],
               intersectLinesSecondPoint=[Line[15]])

propagateGeometry(line=[Line[72],Line[56],Line[54],Line[52]],
               transformationType=3,
               transformationPoint=[Point[1]],
               coordSystem=CoordSys['XY1'],
               repetitionNumber=[12],
               repetitionValue=['30'],
               connectToOrigin=1)

createGeometry(coordSystem=CoordSys['XY1'],
               idPoints=[126,127],
               coordinatesPoints=['-68.89172795197543','0.0','0.0','68.89172795197543','0.0','0.0'],
               idLines=[169,170],
               typeLines=[4,4],
               pointsOfLines=[126,127,1,127,126,1],
               radius=['68.891728','68.891728'],
               angle=['180.000000','180.000000'])

Line[170].radius='68'


createGeometry(coordSystem=CoordSys['XY1'],
               idPoints=[128,129],
               coordinatesPoints=['-77.24470965816387','0.0','0.0','77.24470965816387','0.0','0.0'],
               idLines=[171,172],
               typeLines=[4,4],
               pointsOfLines=[128,129,1,129,128,1],
               radius=['77.244710','77.244710'],
               angle=['180.000000','180.000000'])

Line[172].radius='41.65'


closeSketcher2dContext()

buildFaces()

