#! Flux2D 20.0
loadProject('C:/Users/Xiao/Desktop/SRM_general/SRM_Motor.FLU')

closeProject()

exit()
